import { Board } from './types';

export const BOARDS: Board[] = ['CBSE', 'ICSE', 'Karnataka State Board'];

export const STANDARDS = ['8', '9', '10', '11', '12'];

export const STREAMS = ['Science', 'Commerce', 'Arts'];

export const ADMIN_PASSWORD = 'Janhavi1522'; // Change this to secure your database

export const SUBJECTS_DATA = {
  GENERAL: [ // 8-10
    'Mathematics',
    'Science',
    'Social Science',
    'English',
    'Hindi',
    'Kannada',
    'Computer Applications',
    'Sanskrit'
  ],
  SCIENCE: [ // 11-12
    'Physics',
    'Chemistry',
    'Mathematics',
    'Biology',
    'Computer Science',
    'English',
    'Hindi',
    'Kannada',
    'Electronics',
    'Psychology'
  ],
  COMMERCE: [ // 11-12
    'Accountancy',
    'Business Studies',
    'Economics',
    'Mathematics',
    'Statistics',
    'English',
    'Hindi',
    'Kannada',
    'Computer Science',
    'Informatics Practices'
  ],
  ARTS: [ // 11-12
    'History',
    'Geography',
    'Political Science',
    'Sociology',
    'Psychology',
    'Economics',
    'English',
    'Hindi',
    'Kannada',
    'Home Science'
  ]
};

// Fallback pool for backward compatibility if needed, though mostly replaced by SUBJECTS_DATA
export const SUBJECTS_POOL = [
  ...new Set([
    ...SUBJECTS_DATA.GENERAL,
    ...SUBJECTS_DATA.SCIENCE,
    ...SUBJECTS_DATA.COMMERCE,
    ...SUBJECTS_DATA.ARTS
  ])
];

export const MOCK_TEST_DURATION_CHAPTER = 60; // 1 hour
export const MOCK_TEST_DURATION_FULL = 180; // 3 hours