import { GoogleGenAI, Type } from "@google/genai";
import { User } from "../types";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

export const solveDoubt = async (
  doubt: string,
  history: string,
  user: User
): Promise<string> => {
  const ai = getAiClient();
  const systemPrompt = `You are an expert tutor for ${user.board} Board, Class ${user.standard}. 
  Your goal is to explain concepts clearly and accurately based on the specific syllabus of ${user.board}.
  If the user is confused, try a different explanation method (e.g., using analogies, step-by-step examples).
  Keep answers concise but comprehensive.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        { role: "user", parts: [{ text: `Context History: ${history}\n\nCurrent Question: ${doubt}` }] },
      ],
      config: {
        systemInstruction: systemPrompt,
      },
    });
    return response.text || "I couldn't generate an answer. Please try again.";
  } catch (error) {
    console.error("Doubt solver error:", error);
    return "Sorry, I encountered an error while solving your doubt.";
  }
};

export const generateNotes = async (
  subject: string,
  chapter: string,
  user: User
): Promise<string> => {
  const ai = getAiClient();
  const prompt = `Generate comprehensive study notes for Subject: ${subject}, Chapter: ${chapter}.
  Target Audience: ${user.board} Class ${user.standard} student.
  Format: Markdown. Include key definitions, formulas, important points, and summary. Include all key headlines and their information. Generate complete study usable long notes which can also be used for exam purpose.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text || "Failed to generate notes.";
  } catch (error) {
    console.error("Notes generation error:", error);
    return "Error generating notes.";
  }
};

export const generateMockTest = async (
  subject: string,
  chapter: string,
  isFullSyllabus: boolean,
  user: User
): Promise<{ questions: string[]; totalMarks: number }> => {
  const ai = getAiClient();
  const duration = isFullSyllabus ? "3 hours" : "1 hour";
  const type = isFullSyllabus ? "Full Syllabus" : `Chapter: ${chapter}`;
  
  const prompt = `Create a mock test for ${user.board} Class ${user.standard}, Subject: ${subject}.
  Scope: ${type}.
  Duration: ${duration}.
  
  Return ONLY a JSON object with this structure:
  {
    "questions": ["Question 1", "Question 2", ...],
    "totalMarks": 50
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    const json = JSON.parse(response.text || "{}");
    return {
      questions: json.questions || [],
      totalMarks: json.totalMarks || 50,
    };
  } catch (error) {
    console.error("Test generation error:", error);
    return { questions: ["Error generating questions"], totalMarks: 0 };
  }
};

export const gradeAnswerSheet = async (
  questions: string[],
  imageBase64: string,
  user: User
): Promise<{ score: number; totalMarks: number; feedback: string; correctAnswers: string }> => {
  const ai = getAiClient();
  
  const prompt = `You are a strict examiner for ${user.board}.
  Here are the questions: ${JSON.stringify(questions)}.
  The user has uploaded an image of their handwritten answers.
  
  1. Read the handwriting in the image.
  2. Grade the answers against the questions.
  3. Provide a score, detailed feedback, and the correct answers for review.
  
  Return JSON:
  {
    "score": number,
    "totalMarks": number,
    "feedback": "string (markdown)",
    "correctAnswers": "string (markdown summary of correct answers)"
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash", // Use flash for vision as well
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: imageBase64 } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
      }
    });
    
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Grading error:", error);
    return { score: 0, totalMarks: 0, feedback: "Error processing image.", correctAnswers: "" };
  }
};

export const searchResources = async (query: string): Promise<{ title: string; url: string }[]> => {
  const ai = getAiClient();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    
    // Extract grounding chunks
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const resources: { title: string; url: string }[] = [];
    
    chunks.forEach((chunk: any) => {
      if (chunk.web) {
        resources.push({
          title: chunk.web.title || "Resource",
          url: chunk.web.uri,
        });
      }
    });
    
    return resources;
  } catch (error) {
    console.error("Search error:", error);
    return [];
  }
};

export const generateTimeTable = async (
  schoolEndHour: string,
  user: User
): Promise<any> => {
  const ai = getAiClient();
  const prompt = `Create a weekly study timetable for a ${user.board} Class ${user.standard} student.
  School ends at: ${schoolEndHour}.
  Allocate 4 hours of self-study per day.
  Include subjects: ${user.subjects?.join(", ")}.
  Include a slot for 'Mock Test' on weekends.
  
  Return JSON:
  [
    {
      "day": "Monday",
      "slots": [{"time": "6:00 PM - 7:00 PM", "activity": "Math", "type": "study"}, ...]
    },
    ...
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Timetable error:", error);
    return [];
  }
};
