export type Board = 'CBSE' | 'ICSE' | 'Karnataka State Board';
export type Standard = '8' | '9' | '10' | '11' | '12';
export type Stream = 'Science' | 'Commerce' | 'Arts';

export interface User {
  name: string;
  email: string; // Used as ID
  parentMobile: string;
  board?: Board;
  standard?: Standard;
  stream?: Stream;
  subjects?: string[];
  isRegistered: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface Note {
  id: string;
  subject: string;
  chapter: string;
  content: string; // Markdown
  createdAt: number;
}

export interface MockTest {
  id: string;
  subject: string;
  chapter: string; // 'All' for full syllabus
  questions: string[];
  durationMinutes: number;
  totalMarks: number;
  createdAt: number;
}

export interface TestResult {
  id: string;
  testId: string;
  subject: string;
  chapter: string;
  score: number;
  totalMarks: number;
  feedback: string;
  correctAnswers: string;
  date: number;
}

export interface TimeTableEntry {
  day: string;
  slots: {
    time: string;
    activity: string;
    type: 'study' | 'break' | 'mock-test';
  }[];
}

export interface SearchResult {
  title: string;
  url: string;
}